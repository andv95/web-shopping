<?php
return [
    'type' => [
      'text',
      'textarea',
      'image',
      'images',
      'ck_editor',
    ],

    'group' => [
        'all',
        'home',
        'about',
    ],
];
